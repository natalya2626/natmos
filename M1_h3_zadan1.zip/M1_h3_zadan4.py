
base_triangle = float(input("Введите размер основания треугольника: "))
height_triangle =float(input("Введите размер высоты треугольника: "))
square = (base_triangle*height_triangle)/2
print(f"Плошадь треугольника: {square:.2f}")