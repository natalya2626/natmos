number = int(input("Введите число: "))

if number > 0:
    print("Number is positive")       
elif number < 0: 
    print("Number is negative")       
else:
    print("Number is equal to zero")