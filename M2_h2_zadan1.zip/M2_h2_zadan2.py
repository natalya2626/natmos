months =int(input("Введите номер месяца: "))

if months == 1:
    print("Январь")
elif months == 2:
    print("Февраль")
elif months == 3:
    print("Март")
elif months == 4:
   print("Апрель")
elif months == 5:
    print("Май")
elif months == 6:
    print("Июнь")
elif months == 7:
    print("Июль")
elif months ==8:
    print("Август")
elif months == 9:
    print("Сентябрь")
elif months == 10:
    print("Октябрь")
elif months == 11:
    print("Ноябрь")
elif months ==12:
    print("Декабрь")    